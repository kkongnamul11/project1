from django.contrib import admin
from .models import blog, imageMain

# Register your models here.


admin.site.register(blog)
admin.site.register(imageMain)

